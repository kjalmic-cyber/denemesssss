import React, { useState } from 'react';
import {
  LayoutDashboard, Heart, Package, HandHeart, Globe, FileText, Settings,
  Search, User, ChevronDown, ChevronRight, Users, DollarSign, TrendingUp,
  Bell, LogOut, ArrowLeft, Save
} from 'lucide-react';

// --- Types ---
type MenuItem = {
  title: string;
  icon: React.ElementType;
  subItems?: string[];
};

// --- Data ---
const menuItems: MenuItem[] = [
  { title: 'Giriş', icon: LayoutDashboard },
  { 
    title: 'Bağış', 
    icon: Heart, 
    subItems: ['Bağış türleri', 'Bağış raporları', 'Bağış al', 'Gönüllü Yönetimi', 'Kumbara Talepleri', 'Web sitesi bağışları'] 
  },
  { 
    title: 'Depo/Stok', 
    icon: Package, 
    subItems: ['Kategori tanımları', 'Ürün tanımları', 'Stok Giriş', 'Stok Çıkış', 'Fatura Raporları', 'Depo Sayımı'] 
  },
  { 
    title: 'Yardım', 
    icon: HandHeart, 
    subItems: ['Yardım Raporları', 'İhtiyaç Sahibi Yönetimi'] 
  },
  { 
    title: 'Organizasyon', 
    icon: Globe, 
    subItems: ['Kurban Organizasyonu', 'Su Kuyusu Organizasyonu', 'Diğer Organizasyonlar'] 
  },
  { 
    title: 'Raporlar', 
    icon: FileText, 
    subItems: ['Bağış Raporları', 'Hissedar Raporları', 'Su Kuyusu Raporları', 'Bağışçı Raporları', 'İhtiyaç Sahibi Raporları', 'Tahsilat Raporları', 'Banka Servisleri', 'Sponsor Periyot Raporları'] 
  },
  { 
    title: 'Yönetimsel', 
    icon: Settings, 
    subItems: ['Toplu Sms gönder', 'Toplu E-posta Gönder', 'Sistem Ayarları', 'Banka Hesap Numaraları', 'Gelir/Gider Yönetimi'] 
  },
];

const mockPersonnel = [
  { id: 1, name: 'Ahmet Yılmaz', role: 'Bağış Sorumlusu', email: 'ahmet@dernek.org' },
  { id: 2, name: 'Ayşe Demir', role: 'Gönüllü Koordinatörü', email: 'ayse@dernek.org' },
  { id: 3, name: 'Mehmet Kaya', role: 'Depo Sorumlusu', email: 'mehmet@dernek.org' },
];

// --- Components ---

const SidebarItem = ({ item, isOpen, toggleOpen, onNavigate }: { item: MenuItem, isOpen: boolean, toggleOpen: () => void, onNavigate: (page: string) => void }) => {
  const hasSubItems = item.subItems && item.subItems.length > 0;
  const Icon = item.icon;

  return (
    <div className="mb-1">
      <button
        onClick={() => {
          if (hasSubItems) {
            toggleOpen();
          } else {
            onNavigate(item.title);
          }
        }}
        className={`w-full flex items-center justify-between px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
          isOpen && hasSubItems ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
        }`}
      >
        <div className="flex items-center gap-3">
          <Icon className={`w-5 h-5 ${isOpen && hasSubItems ? 'text-indigo-600' : 'text-slate-400'}`} />
          <span>{item.title}</span>
        </div>
        {hasSubItems && (
          isOpen ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />
        )}
      </button>
      
      {hasSubItems && isOpen && (
        <div className="mt-1 ml-4 pl-4 border-l border-slate-200 space-y-1">
          {item.subItems!.map((subItem, index) => (
            <button
              key={index}
              onClick={() => onNavigate(subItem)}
              className="w-full text-left px-4 py-2 text-sm text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
            >
              {subItem}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

const Sidebar = ({ onNavigate }: { onNavigate: (page: string) => void }) => {
  const [openMenus, setOpenMenus] = useState<Record<string, boolean>>({ 'Bağış': true });

  const toggleMenu = (title: string) => {
    setOpenMenus(prev => ({ ...prev, [title]: !prev[title] }));
  };

  return (
    <aside className="w-64 bg-white border-r border-slate-200 h-screen flex flex-col fixed left-0 top-0 z-20">
      <div className="h-16 flex items-center px-6 border-b border-slate-200">
        <div className="flex items-center gap-2 text-indigo-600">
          <Heart className="w-6 h-6 fill-current" />
          <span className="text-xl font-bold text-slate-900">DernekCRM</span>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        {menuItems.map((item, index) => (
          <SidebarItem 
            key={index} 
            item={item} 
            isOpen={!!openMenus[item.title]} 
            toggleOpen={() => toggleMenu(item.title)} 
            onNavigate={onNavigate}
          />
        ))}
      </div>
    </aside>
  );
};

const Header = () => {
  const [profileOpen, setProfileOpen] = useState(false);

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="flex-1 flex justify-center">
        <div className="max-w-md w-full relative">
          <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input 
            type="text" 
            placeholder="Bağışçı, personel veya işlem ara..." 
            className="w-full pl-10 pr-4 py-2 bg-slate-100 border-transparent rounded-full text-sm focus:bg-white focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 transition-all outline-none"
          />
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <button className="p-2 text-slate-400 hover:text-slate-600 relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
        
        <div className="relative">
          <button 
            onClick={() => setProfileOpen(!profileOpen)}
            className="flex items-center gap-2 p-1 rounded-full hover:bg-slate-100 transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 font-semibold">
              YD
            </div>
          </button>

          {profileOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-100 py-1">
              <button className="w-full flex items-center gap-2 px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">
                <User className="w-4 h-4" />
                Kişisel Bilgiler
              </button>
              <div className="h-px bg-slate-100 my-1"></div>
              <button className="w-full flex items-center gap-2 px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                <LogOut className="w-4 h-4" />
                Çıkış Yap
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

const Dashboard = () => {
  return (
    <main className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 text-sm mt-1">Dernek özet verileri ve son durumlar.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <span className="text-sm font-medium text-green-600 bg-green-50 px-2 py-1 rounded-md">+12%</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Toplam Bağışçı</h3>
          <p className="text-2xl font-bold text-slate-900 mt-1">1,248</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center">
              <User className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Personel Sayısı</h3>
          <p className="text-2xl font-bold text-slate-900 mt-1">24</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6" />
            </div>
            <span className="text-sm font-medium text-green-600 bg-green-50 px-2 py-1 rounded-md">+5%</span>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Günlük Bağış</h3>
          <p className="text-2xl font-bold text-slate-900 mt-1">₺12,450</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-violet-50 text-violet-600 rounded-xl flex items-center justify-center">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
          <h3 className="text-slate-500 text-sm font-medium">Toplam Bağış</h3>
          <p className="text-2xl font-bold text-slate-900 mt-1">₺1,450,000</p>
        </div>
      </div>

      {/* Personnel Section */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">Personel Kartları</h2>
          <button className="text-sm text-indigo-600 font-medium hover:text-indigo-700">Tümünü Gör</button>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockPersonnel.map((person) => (
              <div key={person.id} className="flex items-start gap-4 p-4 rounded-xl border border-slate-100 hover:border-indigo-100 hover:shadow-md transition-all group cursor-pointer">
                <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-semibold group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                  {person.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">{person.name}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{person.role}</p>
                  <p className="text-xs text-slate-400 mt-2">{person.email}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  );
};

const BagisAlPage = ({ onBack }: { onBack: () => void }) => {
  return (
    <main className="p-8 max-w-7xl mx-auto">
      {/* Top Bar */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack} 
            className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Geri Dön</span>
          </button>
          <div className="h-6 w-px bg-slate-200"></div>
          <h1 className="text-2xl font-bold text-slate-900">Bağış Al</h1>
        </div>
        <button className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2.5 rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-sm">
          <Save className="w-5 h-5" />
          Kaydet
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column: Bağışçı Bilgileri */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-fit">
          <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/50">
            <h2 className="text-lg font-semibold text-slate-900">Bağışçı Bilgileri</h2>
          </div>
          <div className="p-6 space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağışçı Telefon</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                  placeholder="05XX XXX XX XX" 
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağışçı Telefon 2</label>
                <input 
                  type="text" 
                  className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                  placeholder="05XX XXX XX XX" 
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağışçı Adı Soyadı</label>
              <input 
                type="text" 
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                placeholder="Ad Soyad" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağışçı E-posta</label>
              <input 
                type="email" 
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                placeholder="ornek@email.com" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağış Referansı</label>
              <div className="relative">
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm appearance-none">
                  <option value="">Seçiniz...</option>
                  <option value="sosyal_medya">Sosyal Medya</option>
                  <option value="arkadas">Arkadaş Tavsiyesi</option>
                  <option value="etkinlik">Etkinlik</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>

            <div className="pt-6 mt-6 border-t border-slate-100">
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağış Kimin Adına</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                    placeholder="Ad Soyad" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Telefon Numarası</label>
                  <input 
                    type="text" 
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm" 
                    placeholder="05XX XXX XX XX" 
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Bağış Bilgileri */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden h-fit">
          <div className="px-6 py-5 border-b border-slate-100 bg-slate-50/50">
            <h2 className="text-lg font-semibold text-slate-900">Bağış Bilgileri</h2>
          </div>
          <div className="p-6 space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağış Yeri</label>
              <div className="relative">
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm appearance-none">
                  <option value="">Seçiniz...</option>
                  <option value="merkez">Genel Merkez</option>
                  <option value="sube_istanbul">İstanbul Şubesi</option>
                  <option value="sube_ankara">Ankara Şubesi</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Durum</label>
              <div className="relative">
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm appearance-none">
                  <option value="">Seçiniz...</option>
                  <option value="bekliyor">Bekliyor</option>
                  <option value="onaylandi">Onaylandı</option>
                  <option value="iptal">İptal Edildi</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağış Ana Kategorisi</label>
              <div className="relative">
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm appearance-none">
                  <option value="">Seçiniz...</option>
                  <option value="nakdi">Nakdi Bağış</option>
                  <option value="ayni">Ayni Bağış</option>
                  <option value="sartli">Şartlı Bağış</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Bağış Alt Kategorisi</label>
              <div className="relative">
                <select className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-200 focus:border-indigo-500 outline-none transition-all text-sm appearance-none">
                  <option value="">Seçiniz...</option>
                  <option value="zekat">Zekat</option>
                  <option value="sadaka">Sadaka</option>
                  <option value="kurban">Kurban</option>
                  <option value="su_kuyusu">Su Kuyusu</option>
                  <option value="egitim">Eğitim Yardımı</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default function App() {
  const [currentPage, setCurrentPage] = useState('Giriş');

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex font-sans">
      <Sidebar onNavigate={handleNavigate} />
      <div className="flex-1 ml-64 flex flex-col min-h-screen">
        <Header />
        <div className="flex-1 overflow-auto">
          {currentPage === 'Bağış al' ? (
            <BagisAlPage onBack={() => setCurrentPage('Giriş')} />
          ) : (
            <Dashboard />
          )}
        </div>
      </div>
    </div>
  );
}
