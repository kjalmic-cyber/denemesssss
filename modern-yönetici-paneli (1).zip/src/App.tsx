import React, { useState, useEffect } from 'react';
import { 
  Users, 
  DollarSign, 
  ShoppingBag, 
  Activity,
  ArrowUpRight,
  Download,
  Loader2
} from 'lucide-react';
import { Sidebar } from './components/Sidebar';
import { Navbar } from './components/Navbar';
import { StatsCard } from './components/StatsCard';
import { DashboardCharts } from './components/Charts';
import { UserTable } from './components/UserTable';
import { Login } from './components/Login';
import { AdminSettings } from './components/AdminSettings';
import { UserManagement } from './components/UserManagement';
import { DynamicPage } from './components/DynamicPage';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState('dashboard');
  const [viewData, setViewData] = useState<any>(null);
  const [settings, setSettings] = useState<any>({});
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  useEffect(() => {
    checkAuth();
    fetchSettings();
  }, []);

  const handleViewChange = (newView: string, data?: any) => {
    setView(newView);
    setViewData(data);
    if (newView === 'dynamic_page') {
      setSidebarCollapsed(true);
    }
  };

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/me');
      if (response.ok) {
        const data = await response.json();
        setUser(data.user);
      }
    } catch (err) {
      console.error('Auth check failed');
    } finally {
      setLoading(false);
    }
  };

  const fetchSettings = async () => {
    const res = await fetch('/api/settings');
    const data = await res.json();
    setSettings(data);
  };

  const handleLogout = async () => {
    await fetch('/api/logout', { method: 'POST' });
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={(userData) => setUser(userData)} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 font-sans text-slate-900">
      <Sidebar 
        onLogout={handleLogout} 
        onViewChange={handleViewChange} 
        isCollapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Navbar user={user} onLogout={handleLogout} onViewChange={handleViewChange} />
        
        <main className={cn(
          "flex-1 overflow-y-auto transition-all duration-300",
          view === 'dynamic_page' ? "p-2 md:p-4" : "p-4 md:p-8"
        )}>
          <motion.div 
            key={view + (viewData?.id || '')}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className={cn(
              "mx-auto transition-all duration-300",
              view === 'dynamic_page' ? "max-w-full" : "max-w-7xl"
            )}
          >
            {view === 'dashboard' && (
              <>
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                  <div>
                    <h1 className="text-2xl font-bold text-slate-900">{settings.app_title || 'Panel Genel Bakış'}</h1>
                    <p className="text-slate-500 mt-1">{settings.app_subtitle || 'Tekrar hoş geldiniz.'}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
                      <Download className="w-4 h-4" />
                      Raporu Dışa Aktar
                    </button>
                    <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 rounded-xl text-sm font-semibold text-white hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-500/20">
                      <ArrowUpRight className="w-4 h-4" />
                      Yeni Oluştur
                    </button>
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                  <StatsCard 
                    title="Toplam Gelir" 
                    value="₺128.430" 
                    change="12.5%" 
                    trend="up" 
                    icon={DollarSign} 
                    color="bg-indigo-500"
                  />
                  <StatsCard 
                    title="Aktif Kullanıcılar" 
                    value="2.420" 
                    change="8.2%" 
                    trend="up" 
                    icon={Users} 
                    color="bg-emerald-500"
                  />
                  <StatsCard 
                    title="Toplam Satış" 
                    value="1.210" 
                    change="3.1%" 
                    trend="down" 
                    icon={ShoppingBag} 
                    color="bg-amber-500"
                  />
                  <StatsCard 
                    title="Ort. Oturum" 
                    value="4dk 32sn" 
                    change="5.4%" 
                    trend="up" 
                    icon={Activity} 
                    color="bg-rose-500"
                  />
                </div>

                {/* Charts Section */}
                <DashboardCharts />

                {/* Table Section */}
                <UserTable />
              </>
            )}

            {view === 'admin_settings' && <AdminSettings />}
            
            {view === 'user_settings' && (
              user?.role === 'admin' ? <UserManagement /> : (
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <h2 className="text-xl font-bold text-slate-900 mb-4">Kullanıcı Ayarları</h2>
                  <p className="text-slate-500">Kendi profil ayarlarınızı buradan yapabilirsiniz (Yakında).</p>
                  <button onClick={() => setView('dashboard')} className="mt-4 text-indigo-600 font-bold">Panele Dön</button>
                </div>
              )
            )}

            {view === 'dynamic_page' && (
              <DynamicPage 
                item={viewData} 
                isAdmin={user?.role === 'admin'} 
                onRefresh={() => {
                  // Refresh sidebar menu to get updated content
                  window.dispatchEvent(new CustomEvent('refresh-menu'));
                }}
              />
            )}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
