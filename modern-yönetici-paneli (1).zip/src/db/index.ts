import Database from 'better-sqlite3';
import path from 'path';

const db = new Database('admin_panel.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    status TEXT NOT NULL DEFAULT 'Aktif',
    avatar TEXT
  );

  CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS menu_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    label TEXT NOT NULL,
    icon TEXT NOT NULL,
    parent_id INTEGER DEFAULT NULL,
    order_index INTEGER DEFAULT 0,
    content TEXT DEFAULT '',
    FOREIGN KEY (parent_id) REFERENCES menu_items (id)
  );

  CREATE TABLE IF NOT EXISTS form_submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    page_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    data TEXT NOT NULL,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (page_id) REFERENCES menu_items (id),
    FOREIGN KEY (user_id) REFERENCES users (id),
    UNIQUE(page_id, user_id)
  );
`);

// Migration: Add content column if it doesn't exist
try {
  db.prepare('SELECT content FROM menu_items LIMIT 1').get();
} catch (e) {
  db.exec('ALTER TABLE menu_items ADD COLUMN content TEXT DEFAULT ""');
}

// Seed initial settings
const settingsCount = db.prepare('SELECT COUNT(*) as count FROM settings').get() as { count: number };
if (settingsCount.count === 0) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('app_title', 'Yönetim Paneli');
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)').run('app_subtitle', 'Tekrar hoş geldiniz, bugün neler olduğuna bir göz atın.');
}

// Seed initial menu items
const menuCount = db.prepare('SELECT COUNT(*) as count FROM menu_items').get() as { count: number };
if (menuCount.count === 0) {
  const insertMenu = db.prepare('INSERT INTO menu_items (label, icon, parent_id, order_index) VALUES (?, ?, ?, ?)');
  insertMenu.run('Panel', 'LayoutDashboard', null, 0);
  insertMenu.run('Kullanıcılar', 'Users', null, 1);
  insertMenu.run('Analizler', 'BarChart3', null, 2);
  insertMenu.run('Raporlar', 'PieChart', null, 3);
  insertMenu.run('Ayarlar', 'Settings', null, 4);
  
  // Sub-menus for Raporlar
  const reportsId = db.prepare('SELECT id FROM menu_items WHERE label = ?').get('Raporlar') as { id: number };
  insertMenu.run('Satış Raporları', 'TrendingUp', reportsId.id, 0);
  insertMenu.run('Kullanıcı Raporları', 'UserCheck', reportsId.id, 1);
}

// Seed initial users if empty
const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
if (userCount.count === 0) {
  const insertUser = db.prepare('INSERT INTO users (username, password, name, email, role, status, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)');
  insertUser.run('admin', 'admin123', 'Yönetici Can', 'admin@example.com', 'admin', 'Aktif', 'YC');
  insertUser.run('user1', 'user123', 'Selin Demir', 'selin@example.com', 'user', 'Aktif', 'SD');
  insertUser.run('user2', 'user123', 'Mert Çetin', 'mert@example.com', 'user', 'Pasif', 'MÇ');
}

export default db;
