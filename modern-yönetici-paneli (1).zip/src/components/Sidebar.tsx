import React, { useEffect, useState } from 'react';
import * as Icons from 'lucide-react';
import { 
  ChevronRight,
  LogOut,
  Shield,
  ChevronDown
} from 'lucide-react';
import { cn } from '@/src/lib/utils';

interface SidebarProps {
  onLogout: () => void;
  onViewChange: (view: string, data?: any) => void;
  isCollapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ onLogout, onViewChange, isCollapsed, onToggle }: SidebarProps) {
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [expandedItems, setExpandedItems] = useState<number[]>([]);
  const [appTitle, setAppTitle] = useState('YönetimUI');

  useEffect(() => {
    fetchMenu();
    fetchSettings();
    window.addEventListener('refresh-menu', fetchMenu);
    return () => window.removeEventListener('refresh-menu', fetchMenu);
  }, []);

  const fetchMenu = async () => {
    const res = await fetch('/api/menu');
    const data = await res.json();
    setMenuItems(data);
  };

  const fetchSettings = async () => {
    const res = await fetch('/api/settings');
    const data = await res.json();
    if (data.app_title) setAppTitle(data.app_title);
  };

  const toggleExpand = (id: number) => {
    if (isCollapsed) {
      onToggle();
      setExpandedItems([id]);
      return;
    }
    setExpandedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const renderMenuItem = (item: any, depth = 0) => {
    const IconComponent = (Icons as any)[item.icon] || Icons.Circle;
    const hasChildren = item.children && item.children.length > 0;
    const isExpanded = expandedItems.includes(item.id);

    return (
      <div key={item.id} className="w-full">
        <button
          onClick={() => {
            if (hasChildren) {
              toggleExpand(item.id);
            } else {
              onViewChange('dynamic_page', item);
            }
          }}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2 rounded-xl transition-all duration-200 group",
            "hover:bg-slate-800 hover:text-white text-slate-400",
            depth > 0 && "text-sm",
            isCollapsed && "justify-center px-0"
          )}
          style={{ paddingLeft: isCollapsed ? undefined : `${(depth * 1.5) + 0.75}rem` }}
          title={isCollapsed ? item.label : undefined}
        >
          <div className={cn(
            "w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-200 shrink-0",
            "bg-slate-800/50 group-hover:bg-indigo-500/10 group-hover:text-indigo-400",
            isCollapsed && "w-10 h-10"
          )}>
            <IconComponent className="w-4 h-4" />
          </div>
          {!isCollapsed && <span className="truncate font-medium">{item.label}</span>}
          {hasChildren && !isCollapsed && (
            <div className="ml-auto shrink-0 opacity-40 group-hover:opacity-100">
              {isExpanded ? <Icons.ChevronDown className="w-4 h-4" /> : <Icons.ChevronRight className="w-4 h-4" />}
            </div>
          )}
        </button>
        
        {hasChildren && isExpanded && !isCollapsed && (
          <div className="mt-1 space-y-1">
            {item.children.map((child: any) => renderMenuItem(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside className={cn(
      "bg-slate-900 text-slate-300 h-screen flex flex-col border-r border-slate-800 transition-all duration-300 relative",
      isCollapsed ? "w-20" : "w-64"
    )}>
      <div className={cn(
        "p-6 flex items-center gap-3",
        isCollapsed && "justify-center px-0"
      )}>
        <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center shrink-0">
          <Shield className="text-white w-5 h-5" />
        </div>
        {!isCollapsed && <span className="font-bold text-xl text-white tracking-tight truncate">Meyx</span>}
      </div>

      <button 
        onClick={onToggle}
        className="absolute -right-3 top-20 w-6 h-6 bg-slate-800 border border-slate-700 rounded-full flex items-center justify-center text-slate-400 hover:text-white shadow-lg z-50"
      >
        {isCollapsed ? <Icons.ChevronRight className="w-3 h-3" /> : <Icons.ChevronLeft className="w-3 h-3" />}
      </button>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto scrollbar-hide">
        {menuItems.map(item => renderMenuItem(item))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <button 
          onClick={onLogout}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-slate-800 hover:text-white transition-all text-slate-400",
            isCollapsed && "justify-center px-0"
          )}
          title={isCollapsed ? "Çıkış Yap" : undefined}
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {!isCollapsed && <span className="font-medium">Çıkış Yap</span>}
        </button>
      </div>
    </aside>
  );
}
