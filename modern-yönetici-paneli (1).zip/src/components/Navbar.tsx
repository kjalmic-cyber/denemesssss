import React, { useState } from 'react';
import { Search, Bell, User, Menu, LogOut, UserPlus, ChevronDown, Settings, UserCog, Layout } from 'lucide-react';

interface NavbarProps {
  user: any;
  onLogout: () => void;
  onViewChange: (view: string, data?: any) => void;
}

export function Navbar({ user, onLogout, onViewChange }: NavbarProps) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-20 shadow-sm">
      <div className="flex items-center gap-4 flex-1">
        <button className="lg:hidden p-2 hover:bg-slate-100 rounded-lg">
          <Menu className="w-5 h-5 text-slate-600" />
        </button>
        <div className="relative max-w-md w-full hidden md:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input 
            type="text" 
            placeholder="Panelde ara..." 
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </button>
        <div className="h-8 w-px bg-slate-200 mx-2"></div>
        
        <div className="relative">
          <div 
            className="flex items-center gap-3 cursor-pointer hover:bg-slate-50 p-1.5 rounded-lg transition-all"
            onClick={() => setShowProfileMenu(!showProfileMenu)}
          >
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold text-slate-900">{user?.name}</p>
              <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">
                {user?.role === 'admin' ? 'Yönetici' : user?.role === 'başkan' ? 'Başkan' : user?.role === 'başkan_yardımcısı' ? 'Başkan Yard.' : 'Kullanıcı'}
              </p>
            </div>
            <div className="w-9 h-9 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold border border-indigo-200">
              {user?.avatar || 'U'}
            </div>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showProfileMenu ? 'rotate-180' : ''}`} />
          </div>

          {showProfileMenu && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowProfileMenu(false)}></div>
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-20 overflow-hidden">
                <div className="px-4 py-3 border-b border-slate-50 mb-1">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Hesap</p>
                  <p className="text-sm font-bold text-slate-900 truncate">{user?.email}</p>
                </div>

                {user?.role === 'admin' && (
                  <button 
                    onClick={() => { onViewChange('admin_settings'); setShowProfileMenu(false); }}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-all"
                  >
                    <Layout className="w-4 h-4" />
                    Panel Düzenle
                  </button>
                )}

                <button 
                  onClick={() => { onViewChange('user_settings'); setShowProfileMenu(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-all"
                >
                  <UserCog className="w-4 h-4" />
                  Kullanıcı Ayarları
                </button>

                <div className="h-px bg-slate-50 my-1"></div>

                <button 
                  onClick={() => { onLogout(); setShowProfileMenu(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 hover:text-indigo-600 transition-all"
                >
                  <UserPlus className="w-4 h-4" />
                  Kullanıcı Değiştir
                </button>
                <button 
                  onClick={() => { onLogout(); setShowProfileMenu(false); }}
                  className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-rose-600 hover:bg-rose-50 transition-all"
                >
                  <LogOut className="w-4 h-4" />
                  Çıkış Yap
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
