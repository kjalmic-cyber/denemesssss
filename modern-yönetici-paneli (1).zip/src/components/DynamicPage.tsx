import React, { useState, useEffect, useCallback } from 'react';
import { 
  Save, Check, Loader2, FileText, Edit3, Plus, Trash2, 
  ChevronRight, ChevronDown, Type, List, Layers, 
  ArrowUp, ArrowDown, GripVertical, AlignLeft, 
  Square, Circle, ChevronDownSquare, Settings2,
  PlusCircle, X, Calendar, Hash, ToggleLeft, AlignJustify,
  Maximize2, Type as FontIcon, Move, PlayCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
  DragStartEvent,
  defaultDropAnimationSideEffects,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { cn } from '../lib/utils';

const fonts = ['Inter', 'Roboto', 'Playfair Display', 'JetBrains Mono', 'Montserrat'];

type ElementType = 'heading' | 'text' | 'textarea' | 'select' | 'checkbox' | 'radio' | 'date' | 'number' | 'toggle' | 'button';
type ElementWidth = 'full' | 'half' | 'third' | number; // number for 1-12 grid

interface PageElement {
  id: string;
  type: ElementType;
  label: string;
  placeholder?: string;
  options?: string[];
  required?: boolean;
  width?: ElementWidth;
  fontSize?: number;
  fontFamily?: string;
  height?: number;
}

interface PageSection {
  id: string;
  title: string;
  elements: PageElement[];
}

interface DynamicPageProps {
  item: any;
  isAdmin: boolean;
  onRefresh: () => void;
}

interface SortableElementProps {
  key?: string;
  element: PageElement;
  sectionId: string;
  index: number;
  isEditing: boolean;
  editingElement: { sectionId: string; elementId: string } | null;
  setEditingElement: (val: { sectionId: string; elementId: string } | null) => void;
  updateElement: (sectionId: string, elementId: string, updates: Partial<PageElement>) => void;
  deleteElement: (sectionId: string, elementId: string) => void;
  elementValues: Record<string, any>;
  setElementValues: (val: Record<string, any>) => void;
  handleFormSubmit?: () => void;
  loading?: boolean;
}

const SortableElement = ({ 
  element, 
  sectionId, 
  index, 
  isEditing, 
  editingElement, 
  setEditingElement, 
  updateElement, 
  deleteElement,
  elementValues,
  setElementValues,
  handleFormSubmit,
  loading
}: SortableElementProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: element.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const isCurrentEditing = editingElement?.elementId === element.id;
  
  const getWidthClass = (width: ElementWidth = 12) => {
    if (width === 'full') return 'col-span-12';
    if (width === 'half') return 'col-span-6';
    if (width === 'third') return 'col-span-4';
    return `col-span-${width}`;
  };

  return (
    <div 
      ref={setNodeRef} 
      style={style}
      className={`${getWidthClass(element.width)} group relative bg-slate-50/50 rounded-2xl border ${isCurrentEditing ? 'border-indigo-500 ring-2 ring-indigo-500/10' : 'border-transparent hover:border-slate-200'} p-4 transition-all`}
    >
      {isEditing && (
        <div className="absolute -left-10 top-4 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity z-10">
          <div {...attributes} {...listeners} className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 shadow-sm cursor-grab active:cursor-grabbing">
            <Move className="w-3.5 h-3.5" />
          </div>
        </div>
      )}

      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 space-y-3" style={{ height: element.height ? `${element.height}px` : 'auto' }}>
          {element.type === 'heading' ? (
            <h3 
              className="font-bold text-slate-900"
              style={{ fontSize: `${element.fontSize}px`, fontFamily: element.fontFamily }}
            >
              {element.label}
            </h3>
          ) : (
            <div className="space-y-2">
              <label 
                className="text-sm font-semibold text-slate-700 flex items-center gap-2"
                style={{ fontSize: `${element.fontSize}px`, fontFamily: element.fontFamily }}
              >
                {element.label}
                {element.required && <span className="text-rose-500">*</span>}
              </label>
              
              {element.type === 'text' && (
                <input 
                  type="text" 
                  placeholder={element.placeholder} 
                  value={elementValues[element.id] || ''}
                  onChange={(e) => setElementValues({ ...elementValues, [element.id]: e.target.value })}
                  className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none" 
                />
              )}

              {element.type === 'textarea' && (
                <textarea 
                  placeholder={element.placeholder} 
                  value={elementValues[element.id] || ''}
                  onChange={(e) => setElementValues({ ...elementValues, [element.id]: e.target.value })}
                  className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm min-h-[80px] focus:ring-2 focus:ring-indigo-500/20 outline-none" 
                />
              )}

              {element.type === 'number' && (
                <input 
                  type="number" 
                  placeholder={element.placeholder} 
                  value={elementValues[element.id] || ''}
                  onChange={(e) => setElementValues({ ...elementValues, [element.id]: e.target.value })}
                  className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none" 
                />
              )}

              {element.type === 'date' && (
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="date" 
                    value={elementValues[element.id] || ''}
                    onChange={(e) => setElementValues({ ...elementValues, [element.id]: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none" 
                  />
                </div>
              )}

              {element.type === 'toggle' && (
                <button 
                  onClick={() => setElementValues({ ...elementValues, [element.id]: !elementValues[element.id] })}
                  className="flex items-center gap-2"
                >
                  <div className={`w-10 h-5 rounded-full relative transition-colors ${elementValues[element.id] ? 'bg-indigo-600' : 'bg-slate-200'}`}>
                    <motion.div 
                      animate={{ x: elementValues[element.id] ? 20 : 4 }}
                      className="absolute top-1 w-3 h-3 bg-white rounded-full"
                    />
                  </div>
                  <span className="text-sm text-slate-600">{elementValues[element.id] ? 'Açık' : 'Kapalı'}</span>
                </button>
              )}

              {element.type === 'select' && (
                <div className="relative">
                  <select 
                    value={elementValues[element.id] || ''}
                    onChange={(e) => setElementValues({ ...elementValues, [element.id]: e.target.value })}
                    className="w-full px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm appearance-none focus:ring-2 focus:ring-indigo-500/20 outline-none"
                  >
                    <option value="">Seçiniz...</option>
                    {element.options?.map((opt, i) => <option key={i} value={opt}>{opt}</option>)}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>
              )}

              {element.type === 'checkbox' && (
                <button 
                  onClick={() => setElementValues({ ...elementValues, [element.id]: !elementValues[element.id] })}
                  className="flex items-center gap-2"
                >
                  <div className={`w-5 h-5 border-2 rounded-md flex items-center justify-center transition-colors ${elementValues[element.id] ? 'bg-indigo-600 border-indigo-600' : 'border-slate-200 bg-white'}`}>
                    {elementValues[element.id] && <Check className="w-3 h-3 text-white" />}
                  </div>
                  <span className="text-sm text-slate-600">{element.label}</span>
                </button>
              )}

              {element.type === 'radio' && (
                <div className="space-y-2">
                  {element.options?.map((opt, i) => (
                    <button 
                      key={i} 
                      onClick={() => setElementValues({ ...elementValues, [element.id]: opt })}
                      className="flex items-center gap-2 w-full text-left"
                    >
                      <div className={`w-5 h-5 border-2 rounded-full flex items-center justify-center transition-colors ${elementValues[element.id] === opt ? 'border-indigo-600' : 'border-slate-200 bg-white'}`}>
                        {elementValues[element.id] === opt && <div className="w-2 h-2 bg-indigo-600 rounded-full" />}
                      </div>
                      <span className="text-sm text-slate-600">{opt}</span>
                    </button>
                  ))}
                </div>
              )}

              {element.type === 'button' && (
                <button 
                  onClick={() => !isEditing && handleFormSubmit?.()}
                  disabled={loading}
                  className="w-full py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center gap-2 disabled:opacity-50"
                  style={{ fontSize: `${element.fontSize}px`, fontFamily: element.fontFamily }}
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {element.label || 'Kaydet'}
                </button>
              )}
            </div>
          )}
        </div>

        {isEditing && (
          <div className="flex items-center gap-1">
            <button 
              onClick={() => setEditingElement(isCurrentEditing ? null : { sectionId, elementId: element.id })}
              className={`p-2 rounded-xl transition-all ${isCurrentEditing ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-200 hover:text-slate-600'}`}
            >
              <Settings2 className="w-4 h-4" />
            </button>
            <button 
              onClick={() => deleteElement(sectionId, element.id)}
              className="p-2 text-rose-400 hover:bg-rose-50 hover:text-rose-600 rounded-xl transition-all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Resize Handle */}
      {isEditing && isCurrentEditing && (
        <div 
          className="absolute bottom-0 right-0 w-6 h-6 cursor-nwse-resize flex items-center justify-center text-slate-300 hover:text-indigo-500"
          onMouseDown={(e) => {
            e.preventDefault();
            const startX = e.clientX;
            const startY = e.clientY;
            const startWidth = typeof element.width === 'number' ? element.width : 12;
            const startHeight = element.height || 60;

            const onMouseMove = (moveEvent: MouseEvent) => {
              const deltaX = moveEvent.clientX - startX;
              const deltaY = moveEvent.clientY - startY;
              
              // Grid width calculation (approximate 80px per column)
              const newWidth = Math.max(2, Math.min(12, startWidth + Math.round(deltaX / 80)));
              const newHeight = Math.max(40, startHeight + deltaY);
              
              updateElement(sectionId, element.id, { width: newWidth, height: newHeight });
            };

            const onMouseUp = () => {
              document.removeEventListener('mousemove', onMouseMove);
              document.removeEventListener('mouseup', onMouseUp);
            };

            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
          }}
        >
          <Maximize2 className="w-3 h-3 rotate-90" />
        </div>
      )}
    </div>
  );
};

export function DynamicPage({ item: initialItem, isAdmin, onRefresh }: DynamicPageProps) {
  const [item, setItem] = useState(initialItem);
  const [sections, setSections] = useState<PageSection[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [editingElement, setEditingElement] = useState<{sectionId: string, elementId: string} | null>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [elementValues, setElementValues] = useState<Record<string, any>>({});
  const [toolboxCollapsed, setToolboxCollapsed] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    setItem(initialItem);
    try {
      const parsed = JSON.parse(initialItem.content || '[]');
      setSections(Array.isArray(parsed) ? parsed : []);
    } catch (e) {
      setSections([]);
    }
    setIsEditing(false);
    fetchSubmissions();
  }, [initialItem]);

  const fetchSubmissions = async () => {
    try {
      const res = await fetch(`/api/submissions/${initialItem.id}`);
      if (res.ok) {
        const data = await res.json();
        setElementValues(data || {});
      }
    } catch (err) {
      console.error('Failed to fetch submissions');
    }
  };

  const handleFormSubmit = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pageId: item.id, data: elementValues })
      });
      if (res.ok) {
        setMessage('Bilgileriniz başarıyla kaydedildi');
        setTimeout(() => setMessage(''), 3000);
      }
    } catch (err) {
      console.error('Submission failed');
    } finally {
      setLoading(false);
    }
  };

  const generateId = () => Math.random().toString(36).substr(2, 9);

  const handleSave = async () => {
    setLoading(true);
    const contentString = JSON.stringify(sections);
    try {
      const res = await fetch(`/api/menu/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...item, content: contentString })
      });
      if (res.ok) {
        setMessage('İçerik başarıyla kaydedildi');
        setIsEditing(false);
        setItem({ ...item, content: contentString });
        onRefresh();
        setTimeout(() => setMessage(''), 3000);
      }
    } catch (err) {
      console.error('Save failed');
    } finally {
      setLoading(false);
    }
  };

  // Section Actions
  const addSection = () => {
    setSections([...sections, { id: generateId(), title: 'Yeni Bölüm', elements: [] }]);
  };

  const updateSectionTitle = (id: string, title: string) => {
    setSections(sections.map(s => s.id === id ? { ...s, title } : s));
  };

  const deleteSection = (id: string) => {
    setSections(sections.filter(s => s.id !== id));
  };

  const moveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= sections.length) return;
    [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
    setSections(newSections);
  };

  // Element Actions
  const addElement = (sectionId: string, type: ElementType) => {
    const newElement: PageElement = {
      id: generateId(),
      type,
      label: type === 'heading' ? 'Yeni Başlık' : 'Yeni Alan',
      placeholder: 'Buraya yazın...',
      options: (type === 'select' || type === 'radio') ? ['Seçenek 1', 'Seçenek 2'] : undefined,
      required: false,
      width: 12,
      fontSize: type === 'heading' ? 24 : 14,
      fontFamily: 'Inter',
      height: type === 'textarea' ? 120 : undefined
    };

    setSections(sections.map(s => {
      if (s.id === sectionId) {
        return { ...s, elements: [...(s.elements || []), newElement] };
      }
      return s;
    }));
  };

  const updateElement = (sectionId: string, elementId: string, updates: Partial<PageElement>) => {
    setSections(sections.map(s => {
      if (s.id === sectionId) {
        return {
          ...s,
          elements: (s.elements || []).map(el => el.id === elementId ? { ...el, ...updates } : el)
        };
      }
      return s;
    }));
  };

  const deleteElement = (sectionId: string, elementId: string) => {
    setSections(sections.map(s => {
      if (s.id === sectionId) {
        return { ...s, elements: (s.elements || []).filter(el => el.id !== elementId) };
      }
      return s;
    }));
  };

  const moveElement = (sectionId: string, index: number, direction: 'up' | 'down') => {
    setSections(sections.map(s => {
      if (s.id === sectionId) {
        const elements = s.elements || [];
        const newElements = [...elements];
        const targetIndex = direction === 'up' ? index - 1 : index + 1;
        if (targetIndex < 0 || targetIndex >= elements.length) return s;
        [newElements[index], newElements[targetIndex]] = [newElements[targetIndex], newElements[index]];
        return { ...s, elements: newElements };
      }
      return s;
    }));
  };

  const handleDragEnd = (event: DragEndEvent, sectionId: string) => {
    const { active, over } = event;
    setActiveId(null);

    if (over && active.id !== over.id) {
      setSections(sections.map(s => {
        if (s.id === sectionId) {
          const elements = s.elements || [];
          const oldIndex = elements.findIndex(el => el.id === active.id);
          const newIndex = elements.findIndex(el => el.id === over.id);
          return { ...s, elements: arrayMove(elements, oldIndex, newIndex) };
        }
        return s;
      }));
    }
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center">
            <FileText className="w-6 h-6 text-indigo-600" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">{item.label}</h1>
            <p className="text-slate-500 text-sm">Sayfa içeriğini toolbox araçları ile tasarlayın.</p>
          </div>
        </div>

        {isAdmin && (
          <div className="flex items-center gap-3">
            {isEditing ? (
              <>
                <button onClick={() => setIsEditing(false)} className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-xl transition-all">İptal</button>
                <button 
                  onClick={handleSave}
                  disabled={loading}
                  className="flex items-center gap-2 px-6 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Kaydet
                </button>
              </>
            ) : (
              <button onClick={() => setIsEditing(true)} className="flex items-center gap-2 px-6 py-2 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200">
                <Edit3 className="w-4 h-4" /> Düzenle
              </button>
            )}
          </div>
        )}
      </div>

      {message && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="bg-emerald-50 text-emerald-600 p-4 rounded-2xl border border-emerald-100 text-sm flex items-center gap-2">
          <Check className="w-4 h-4" /> {message}
        </motion.div>
      )}

      <div className="flex gap-4 items-start relative">
        {/* Toolbox */}
        <AnimatePresence>
          {isEditing && (
            <motion.div 
              drag
              dragMomentum={false}
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: toolboxCollapsed ? 64 : 260, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="sticky top-24 z-30 cursor-move"
            >
              <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xl space-y-4 overflow-hidden">
                <div className="flex items-center justify-between mb-2">
                  {!toolboxCollapsed && (
                    <div className="flex items-center gap-2">
                      <GripVertical className="w-4 h-4 text-slate-300" />
                      <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Toolbox</h3>
                    </div>
                  )}
                  <button 
                    onClick={() => setToolboxCollapsed(!toolboxCollapsed)}
                    className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 transition-all ml-auto"
                  >
                    {toolboxCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4 rotate-90" />}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { type: 'heading', label: 'Başlık', icon: Type },
                    { type: 'text', label: 'Metin Alanı', icon: AlignLeft },
                    { type: 'textarea', label: 'Uzun Metin', icon: AlignJustify },
                    { type: 'number', label: 'Sayı Alanı', icon: Hash },
                    { type: 'date', label: 'Tarih Seçici', icon: Calendar },
                    { type: 'select', label: 'List Box', icon: ChevronDownSquare },
                    { type: 'checkbox', label: 'Onay Kutusu', icon: Square },
                    { type: 'radio', label: 'Seçenek Grubu', icon: Circle },
                    { type: 'toggle', label: 'Toggle Switch', icon: ToggleLeft },
                    { type: 'button', label: 'Kaydet Butonu', icon: PlayCircle },
                  ].map((tool) => (
                    <button 
                      key={tool.type}
                      onClick={() => {
                        if (sections.length === 0) addSection();
                        const targetSectionId = sections[sections.length - 1]?.id || generateId();
                        addElement(targetSectionId, tool.type as ElementType);
                      }}
                      className={cn(
                        "flex items-center gap-3 p-2.5 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-2xl border border-transparent hover:border-indigo-100 transition-all group",
                        toolboxCollapsed && "justify-center"
                      )}
                      title={toolboxCollapsed ? tool.label : undefined}
                    >
                      <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm group-hover:shadow-indigo-100 transition-all shrink-0">
                        <tool.icon className="w-4 h-4" />
                      </div>
                      {!toolboxCollapsed && <span className="text-sm font-bold truncate">{tool.label}</span>}
                    </button>
                  ))}
                </div>

                {!toolboxCollapsed && (
                  <div className="space-y-2 mt-4">
                    <button 
                      onClick={addSection}
                      className="w-full py-3 bg-slate-100 text-slate-900 rounded-2xl font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> Bölüm Ekle
                    </button>
                    
                    <button 
                      onClick={handleSave}
                      disabled={loading}
                      className="w-full py-3 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 flex items-center justify-center gap-2"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      Değişiklikleri Kaydet
                    </button>
                  </div>
                )}
                
                {toolboxCollapsed && (
                  <div className="flex flex-col gap-2 mt-4">
                    <button 
                      onClick={addSection}
                      className="w-full aspect-square bg-slate-100 text-slate-900 rounded-2xl flex items-center justify-center hover:bg-slate-200 transition-all"
                      title="Bölüm Ekle"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={handleSave}
                      disabled={loading}
                      className="w-full aspect-square bg-indigo-600 text-white rounded-2xl flex items-center justify-center hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
                      title="Kaydet"
                    >
                      {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Canvas */}
        <div className="flex-1 min-w-0 space-y-6">
          {sections.map((section, sIndex) => (
            <div key={section.id} className="group/section relative bg-white p-4 md:p-6 rounded-3xl border border-slate-200 shadow-sm">
              {isEditing && (
                <div className="absolute -left-12 top-8 flex flex-col gap-1 opacity-0 group-hover/section:opacity-100 transition-opacity">
                  <button onClick={() => moveSection(sIndex, 'up')} className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 shadow-sm"><ArrowUp className="w-3.5 h-3.5" /></button>
                  <button onClick={() => moveSection(sIndex, 'down')} className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 shadow-sm"><ArrowDown className="w-3.5 h-3.5" /></button>
                </div>
              )}

              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3 flex-1 mr-4">
                  {isEditing ? (
                    <input 
                      type="text"
                      value={section.title}
                      onChange={(e) => updateSectionTitle(section.id, e.target.value)}
                      className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xl font-bold outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  ) : (
                    <h2 className="text-xl font-bold text-slate-900">{section.title}</h2>
                  )}
                </div>
                {isEditing && (
                  <button onClick={() => deleteSection(section.id)} className="p-2 text-rose-400 hover:bg-rose-50 hover:text-rose-600 rounded-xl transition-all">
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-12 gap-6">
                <DndContext 
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={(e) => handleDragEnd(e, section.id)}
                >
                  <SortableContext 
                    items={(section.elements || []).map(el => el.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {(section.elements || []).map((element, eIndex) => (
                      <SortableElement 
                        key={element.id} 
                        element={element} 
                        sectionId={section.id} 
                        index={eIndex}
                        isEditing={isEditing}
                        editingElement={editingElement}
                        setEditingElement={setEditingElement}
                        updateElement={updateElement}
                        deleteElement={deleteElement}
                        elementValues={elementValues}
                        setElementValues={setElementValues}
                        handleFormSubmit={handleFormSubmit}
                        loading={loading}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
                
                {isEditing && (!section.elements || section.elements.length === 0) && (
                  <div className="col-span-12 py-12 border-2 border-dashed border-slate-100 rounded-3xl flex flex-col items-center justify-center text-slate-400">
                    <PlusCircle className="w-8 h-8 mb-2 opacity-20" />
                    <p className="text-sm font-medium">Toolbox'tan bir araç seçerek başlayın</p>
                  </div>
                )}
              </div>
            </div>
          ))}

          {sections.length === 0 && !isEditing && (
            <div className="bg-white py-20 rounded-3xl border border-slate-200 shadow-sm flex flex-col items-center justify-center text-slate-400">
              <Layers className="w-12 h-12 mb-4 opacity-20" />
              <p>Bu sayfa henüz bir içeriğe sahip değil.</p>
              {isAdmin && <p className="text-sm mt-2">Düzenlemek için yukarıdaki butonu kullanın.</p>}
            </div>
          )}
        </div>
      </div>
      {/* Settings Drawer */}
      <AnimatePresence>
        {isEditing && editingElement && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingElement(null)}
              className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: 400, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 400, opacity: 0 }}
              className="fixed right-0 top-0 bottom-0 w-[400px] bg-white shadow-2xl z-50 flex flex-col border-l border-slate-200"
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-200">
                    <Settings2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900">Öğe Ayarları</h3>
                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">Görünüm ve Davranış</p>
                  </div>
                </div>
                <button 
                  onClick={() => setEditingElement(null)}
                  className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 transition-all"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8">
                {/* Find the current element to render its settings */}
                {(() => {
                  const section = sections.find(s => s.id === editingElement.sectionId);
                  const element = section?.elements.find(el => el.id === editingElement.elementId);
                  if (!element) return null;

                  return (
                    <div className="space-y-8">
                      <div className="space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Etiket / Başlık</label>
                          <input 
                            type="text" 
                            value={element.label}
                            onChange={(e) => updateElement(editingElement.sectionId, element.id, { label: e.target.value })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
                          />
                        </div>
                        {(element.type === 'text' || element.type === 'textarea' || element.type === 'number') && (
                          <div className="space-y-1.5">
                            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Yer Tutucu (Placeholder)</label>
                            <input 
                              type="text" 
                              value={element.placeholder}
                              onChange={(e) => updateElement(editingElement.sectionId, element.id, { placeholder: e.target.value })}
                              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
                            />
                          </div>
                        )}
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                            <FontIcon className="w-3 h-3" /> Yazı Boyutu ({element.fontSize}px)
                          </label>
                          <input 
                            type="range" 
                            min="10" 
                            max="72" 
                            value={element.fontSize}
                            onChange={(e) => updateElement(editingElement.sectionId, element.id, { fontSize: parseInt(e.target.value) })}
                            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Font Ailesi</label>
                          <select 
                            value={element.fontFamily}
                            onChange={(e) => updateElement(editingElement.sectionId, element.id, { fontFamily: e.target.value })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm outline-none appearance-none cursor-pointer"
                          >
                            {fonts.map(f => <option key={f} value={f}>{f}</option>)}
                          </select>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Genişlik (Grid: 1-12)</label>
                          <div className="flex bg-slate-100 p-1 rounded-2xl">
                            {[4, 6, 12].map((w) => (
                              <button
                                key={w}
                                onClick={() => updateElement(editingElement.sectionId, element.id, { width: w })}
                                className={`flex-1 py-2.5 text-[10px] font-bold uppercase rounded-xl transition-all ${element.width === w ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}
                              >
                                {w === 12 ? 'Tam' : w === 6 ? 'Yarım' : 'Üçte Bir'}
                              </button>
                            ))}
                          </div>
                        </div>
                        <div className="pt-2">
                          <label className="flex items-center gap-3 cursor-pointer group">
                            <div className={`w-10 h-6 rounded-full transition-all relative ${element.required ? 'bg-indigo-600' : 'bg-slate-200'}`}>
                              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${element.required ? 'left-5' : 'left-1'}`} />
                            </div>
                            <input 
                              type="checkbox" 
                              className="hidden"
                              checked={element.required}
                              onChange={(e) => updateElement(editingElement.sectionId, element.id, { required: e.target.checked })}
                            />
                            <span className="text-xs font-bold text-slate-600 group-hover:text-slate-900 transition-colors">Zorunlu Alan</span>
                          </label>
                        </div>
                      </div>

                      {(element.type === 'select' || element.type === 'radio') && (
                        <div className="space-y-4">
                          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Seçenekler</label>
                          <div className="space-y-3">
                            {element.options?.map((opt, i) => (
                              <div key={i} className="flex items-center gap-2 group/opt">
                                <input 
                                  type="text" 
                                  value={opt}
                                  onChange={(e) => {
                                    const newOpts = [...(element.options || [])];
                                    newOpts[i] = e.target.value;
                                    updateElement(editingElement.sectionId, element.id, { options: newOpts });
                                  }}
                                  className="flex-1 px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm transition-all focus:bg-white"
                                />
                                <button 
                                  onClick={() => {
                                    const newOpts = element.options?.filter((_, idx) => idx !== i);
                                    updateElement(editingElement.sectionId, element.id, { options: newOpts });
                                  }}
                                  className="p-2 text-slate-300 hover:text-rose-500 transition-colors"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </div>
                            ))}
                            <button 
                              onClick={() => updateElement(editingElement.sectionId, element.id, { options: [...(element.options || []), 'Yeni Seçenek'] })}
                              className="w-full py-3 border-2 border-dashed border-slate-100 rounded-2xl text-xs font-bold text-indigo-600 hover:border-indigo-100 hover:bg-indigo-50/30 transition-all flex items-center justify-center gap-2"
                            >
                              <PlusCircle className="w-4 h-4" /> Seçenek Ekle
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
              
              <div className="p-6 border-t border-slate-100 bg-slate-50/50">
                <button 
                  onClick={() => setEditingElement(null)}
                  className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-lg"
                >
                  Tamam
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
