import React from 'react';
import { MoreVertical, ExternalLink } from 'lucide-react';

const users = [
  { id: 1, name: 'Can Yılmaz', email: 'can@example.com', role: 'Yönetici', status: 'Aktif', avatar: 'CY' },
  { id: 2, name: 'Selin Demir', email: 'selin@example.com', role: 'Editör', status: 'Aktif', avatar: 'SD' },
  { id: 3, name: 'Mert Çetin', email: 'mert@example.com', role: 'Kullanıcı', status: 'Pasif', avatar: 'MÇ' },
  { id: 4, name: 'Elif Kaya', email: 'elif@example.com', role: 'Editör', status: 'Aktif', avatar: 'EK' },
  { id: 5, name: 'Burak Aydın', email: 'burak@example.com', role: 'Kullanıcı', status: 'Beklemede', avatar: 'BA' },
];

export function UserTable() {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <h3 className="font-bold text-slate-900">Son Kullanıcılar</h3>
        <button className="text-indigo-600 text-sm font-semibold hover:underline flex items-center gap-1">
          Hepsini gör <ExternalLink className="w-3 h-3" />
        </button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Kullanıcı</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Rol</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Durum</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">İşlem</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 font-semibold text-sm border border-slate-200">
                      {user.avatar}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-900">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.email}</p>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm text-slate-600">{user.role}</span>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                    user.status === 'Aktif' ? 'bg-emerald-50 text-emerald-700' :
                    user.status === 'Pasif' ? 'bg-slate-100 text-slate-700' :
                    'bg-amber-50 text-amber-700'
                  }`}>
                    {user.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="p-1.5 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
