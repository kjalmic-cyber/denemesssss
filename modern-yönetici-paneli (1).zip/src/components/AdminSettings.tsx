import React, { useState, useEffect } from 'react';
import * as Icons from 'lucide-react';
import { Save, Plus, Trash2, ChevronDown, ChevronUp, Layout, Type, List, Check, Loader2, GripVertical } from 'lucide-react';
import { motion } from 'motion/react';

export function AdminSettings() {
  const [settings, setSettings] = useState<any>({});
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [sRes, mRes] = await Promise.all([
      fetch('/api/settings'),
      fetch('/api/menu')
    ]);
    setSettings(await sRes.json());
    setMenuItems(await mRes.json());
    setLoading(false);
  };

  const handleSaveSettings = async () => {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (res.ok) {
      setMessage('Ayarlar kaydedildi');
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handleAddMenuItem = async (parentId: number | null = null) => {
    const res = await fetch('/api/menu', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        label: 'Yeni Menü',
        icon: 'Circle',
        parent_id: parentId,
        order_index: 99
      })
    });
    if (res.ok) fetchData();
  };

  const handleDeleteMenuItem = async (id: number) => {
    const res = await fetch(`/api/menu/${id}`, { method: 'DELETE' });
    if (res.ok) fetchData();
  };

  const handleUpdateMenuItem = async (id: number, updates: any) => {
    const res = await fetch(`/api/menu/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updates)
    });
    if (res.ok) {
      setMessage('Menü güncellendi');
      fetchData();
      setTimeout(() => setMessage(''), 2000);
    }
  };

  const renderMenuEditor = (items: any[], depth = 0) => {
    return items.map(item => (
      <div key={item.id} className={depth > 0 ? "ml-8 border-l-2 border-slate-100 pl-4 mt-3 space-y-3" : "space-y-3"}>
        <div className="flex items-center gap-3 bg-slate-50/50 p-3 rounded-2xl border border-slate-100 group">
          <div className="p-2 bg-white rounded-lg border border-slate-200 text-slate-400">
            <GripVertical className="w-4 h-4 cursor-move" />
          </div>
          
          <input 
            type="text" 
            defaultValue={item.label}
            onBlur={(e) => {
              if (e.target.value !== item.label) {
                handleUpdateMenuItem(item.id, { ...item, label: e.target.value });
              }
            }}
            className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
            placeholder="Menü adı..."
          />

          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button 
              onClick={() => handleAddMenuItem(item.id)}
              className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all"
              title="Alt Menü Ekle"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button 
              onClick={() => handleDeleteMenuItem(item.id)}
              className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition-all"
              title="Sil"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {item.children && item.children.length > 0 && (
          <div className="space-y-3">
            {renderMenuEditor(item.children, depth + 1)}
          </div>
        )}
      </div>
    ));
  };

  if (loading) return (
    <div className="flex items-center justify-center p-12">
      <Loader2 className="w-8 h-8 text-indigo-600 animate-spin" />
    </div>
  );

  return (
    <div className="space-y-8 pb-20">
      {/* App Settings */}
      <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
            <Layout className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">Genel Panel Ayarları</h2>
            <p className="text-sm text-slate-500">Panelin başlık ve alt başlık bilgilerini düzenleyin.</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 ml-1">Panel Başlığı</label>
            <input 
              type="text" 
              value={settings.app_title || ''}
              onChange={(e) => setSettings({...settings, app_title: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-semibold text-slate-700 ml-1">Panel Alt Başlığı</label>
            <input 
              type="text" 
              value={settings.app_subtitle || ''}
              onChange={(e) => setSettings({...settings, app_subtitle: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
            />
          </div>
        </div>
        
        <div className="mt-8 flex items-center gap-4">
          <button 
            onClick={handleSaveSettings}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
          >
            <Save className="w-4 h-4" />
            Ayarları Kaydet
          </button>
          {message && (
            <motion.p 
              initial={{ opacity: 0, x: -10 }} 
              animate={{ opacity: 1, x: 0 }} 
              className="text-emerald-600 text-sm font-bold flex items-center gap-2"
            >
              <Check className="w-4 h-4" /> {message}
            </motion.p>
          )}
        </div>
      </section>

      {/* Menu Settings */}
      <section className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
              <List className="w-5 h-5 text-indigo-600" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Menü Yönetimi</h2>
              <p className="text-sm text-slate-500">Sınırsız derinlikte menü ve alt menü oluşturun.</p>
            </div>
          </div>
          <button 
            onClick={() => handleAddMenuItem()}
            className="flex items-center gap-2 px-5 py-2.5 bg-slate-900 text-white rounded-xl text-sm font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
          >
            <Plus className="w-4 h-4" />
            Yeni Ana Menü
          </button>
        </div>

        <div className="space-y-6 max-w-3xl">
          {renderMenuEditor(menuItems)}
          {menuItems.length === 0 && (
            <div className="text-center py-12 border-2 border-dashed border-slate-100 rounded-3xl">
              <p className="text-slate-400 text-sm">Henüz menü öğesi eklenmemiş.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
