import express from 'express';
import { createServer as createViteServer } from 'vite';
import cookieParser from 'cookie-parser';
import db from './src/db/index.ts';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const userId = req.cookies.userId;
    if (!userId) return res.status(401).json({ error: 'Yetkisiz erişim' });
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!user) return res.status(401).json({ error: 'Kullanıcı bulunamadı' });
    req.user = user;
    next();
  };

  // API Routes
  app.post('/api/login', (req, res) => {
    const { username, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, password) as any;
    
    if (user) {
      res.cookie('userId', user.id, { 
        httpOnly: true, 
        sameSite: 'none', 
        secure: true 
      });
      db.prepare('INSERT INTO activity_logs (user_id, action) VALUES (?, ?)').run(user.id, 'Giriş yapıldı');
      res.json({ user: { id: user.id, name: user.name, role: user.role, email: user.email, avatar: user.avatar } });
    } else {
      res.status(401).json({ error: 'Geçersiz kullanıcı adı veya şifre' });
    }
  });

  app.post('/api/logout', (req, res) => {
    res.clearCookie('userId');
    res.json({ success: true });
  });

  app.get('/api/me', (req, res) => {
    const userId = req.cookies.userId;
    if (!userId) return res.status(401).json({ error: 'Giriş yapılmamış' });
    const user = db.prepare('SELECT id, name, role, email, avatar FROM users WHERE id = ?').get(userId);
    if (!user) return res.status(401).json({ error: 'Kullanıcı bulunamadı' });
    res.json({ user });
  });

  app.get('/api/settings', (req, res) => {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsMap = (settings as any[]).reduce((acc, s) => ({ ...acc, [s.key]: s.value }), {});
    res.json(settingsMap);
  });

  app.put('/api/settings', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const updates = req.body;
    for (const [key, value] of Object.entries(updates)) {
      db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, value);
    }
    res.json({ success: true });
  });

  app.get('/api/menu', (req, res) => {
    const items = db.prepare('SELECT * FROM menu_items ORDER BY order_index ASC').all() as any[];
    const buildTree = (parentId: number | null = null) => {
      return items
        .filter(item => item.parent_id === parentId)
        .map(item => ({
          ...item,
          children: buildTree(item.id)
        }));
    };
    res.json(buildTree());
  });

  app.post('/api/menu', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { label, icon, parent_id, order_index } = req.body;
    db.prepare('INSERT INTO menu_items (label, icon, parent_id, order_index) VALUES (?, ?, ?, ?)').run(label, icon, parent_id, order_index);
    res.json({ success: true });
  });

  app.put('/api/menu/:id', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { id } = req.params;
    const { label, icon, order_index, content } = req.body;
    db.prepare('UPDATE menu_items SET label = ?, icon = ?, order_index = ?, content = ? WHERE id = ?')
      .run(label, icon, order_index, content || '', id);
    res.json({ success: true });
  });

  app.delete('/api/menu/:id', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { id } = req.params;
    db.prepare('DELETE FROM menu_items WHERE id = ? OR parent_id = ?').run(id, id);
    res.json({ success: true });
  });

  app.get('/api/users', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const users = db.prepare('SELECT id, username, name, email, role, status, avatar FROM users').all();
    res.json({ users });
  });

  app.post('/api/users', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { username, password, name, email, role, status } = req.body;
    try {
      const result = db.prepare('INSERT INTO users (username, password, name, email, role, status, avatar) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(username, password, name, email, role, status, name.split(' ').map((n: string) => n[0]).join('').toUpperCase());
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: 'Kullanıcı adı veya e-posta zaten kullanımda' });
    }
  });

  app.put('/api/users/:id', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { id } = req.params;
    const { name, email, role, status, password } = req.body;
    if (password) {
      db.prepare('UPDATE users SET name = ?, email = ?, role = ?, status = ?, password = ? WHERE id = ?')
        .run(name, email, role, status, password, id);
    } else {
      db.prepare('UPDATE users SET name = ?, email = ?, role = ?, status = ? WHERE id = ?')
        .run(name, email, role, status, id);
    }
    res.json({ success: true });
  });

  app.delete('/api/users/:id', authenticate, (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Yetkiniz yok' });
    const { id } = req.params;
    if (parseInt(id) === req.user.id) return res.status(400).json({ error: 'Kendi hesabınızı silemezsiniz' });
    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    res.json({ success: true });
  });

  // Form Submissions API
  app.get('/api/submissions/:pageId', authenticate, (req: any, res) => {
    const { pageId } = req.params;
    const userId = req.user.id;
    const submission = db.prepare('SELECT data FROM form_submissions WHERE page_id = ? AND user_id = ?').get(pageId, userId) as any;
    res.json(submission ? JSON.parse(submission.data) : {});
  });

  app.post('/api/submissions', authenticate, (req: any, res) => {
    const { pageId, data } = req.body;
    const userId = req.user.id;
    const dataString = JSON.stringify(data);
    
    db.prepare(`
      INSERT INTO form_submissions (page_id, user_id, data, updated_at) 
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(page_id, user_id) DO UPDATE SET 
        data = excluded.data,
        updated_at = CURRENT_TIMESTAMP
    `).run(pageId, userId, dataString);
    
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
